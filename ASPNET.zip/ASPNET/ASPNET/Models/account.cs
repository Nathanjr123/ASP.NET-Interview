﻿using System;
namespace ASPNET.Models
{
	public class account
	{
		public string balance
		{
			get;
			set;
		}
		public string ID_Number
		{
			get;
			set;
		}
		public account()
		{
		}
	}
}


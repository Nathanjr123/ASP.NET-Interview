﻿using System;
namespace ASPNET.Models
{
	public class employee
	{
		public int id
		{
			get;
			set;
		}
		public string lastname
		{
			get;
			set;
		}
		public string phoneNumber
		{
			get;
			set;
		}
		public employee()
		{
		}
	}
}

